﻿namespace se
{
    partial class FeedbackViewForm
    {
        private System.Windows.Forms.ListBox feedbackListBox; // Declare the ListBox control

        // Other members...

        private void InitializeComponent()
        {
            this.feedbackListBox = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // feedbackListBox
            // 
            this.feedbackListBox.FormattingEnabled = true;
            this.feedbackListBox.ItemHeight = 20;
            this.feedbackListBox.Location = new System.Drawing.Point(12, 12);
            this.feedbackListBox.Name = "feedbackListBox";
            this.feedbackListBox.Size = new System.Drawing.Size(776, 424);
            this.feedbackListBox.TabIndex = 0;
            this.feedbackListBox.SelectedIndexChanged += new System.EventHandler(this.feedbackListBox_SelectedIndexChanged);
            // 
            // FeedbackViewForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.feedbackListBox);
            this.Name = "FeedbackViewForm";
            this.Text = "View Feedback";
            this.Load += new System.EventHandler(this.FeedbackViewForm_Load);
            this.ResumeLayout(false);

        }
    }
}
