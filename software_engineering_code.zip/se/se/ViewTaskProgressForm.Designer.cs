﻿namespace se
{
    partial class ViewTaskProgressForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        // Add tasksPanel control declaration
        private System.Windows.Forms.Panel tasksPanel;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.SuspendLayout();

            // Initialize tasksPanel
            this.tasksPanel = new System.Windows.Forms.Panel();
            this.tasksPanel.AutoScroll = true;
            this.tasksPanel.Location = new System.Drawing.Point(20, 20);
            this.tasksPanel.Size = new System.Drawing.Size(760, 400); // Adjust the size as needed
            this.Controls.Add(this.tasksPanel); // Add tasksPanel to the form's controls

            // 
            // ViewTaskProgressForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Name = "ViewTaskProgressForm";
            this.Text = "ViewTaskProgressForm";
            this.Load += new System.EventHandler(this.ViewTaskProgressForm_Load);
            this.ResumeLayout(false);

        }

        #endregion
    }
}
