﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace se
{
    public partial class AssignTasksForm : Form
    {
        private MySqlConnection connection;
        private string userEmail;

        public AssignTasksForm(string userEmail)
        {

            InitializeComponent();
            this.userEmail = userEmail; // Store the user email for later use
            InitializeDatabaseConnection();
            LoadEvents();
            LoadMembers();
        }

        private void InitializeDatabaseConnection()
        {
            string connectionString = "server=localhost;database=se;uid=root;pwd=1234567;";
            connection = new MySqlConnection(connectionString);

        }

        private void AssignTasksForm_Load(object sender, EventArgs e)
        {
            // Optional: You can perform any additional initialization here
        }

        private void LoadEvents()
        {
            try
            {
                connection.Open();
                string query = "SELECT Events.title " +
                               "FROM Events " +
                               "INNER JOIN Societies ON Events.society_id = Societies.society_id " +
                               "INNER JOIN SocietyMemberships ON Societies.society_id = SocietyMemberships.society_id " +
                               "INNER JOIN Users ON SocietyMemberships.user_id = Users.user_id " +
                               "WHERE Users.email = @UserEmail";
                MySqlCommand command = new MySqlCommand(query, connection);
                command.Parameters.AddWithValue("@UserEmail", userEmail);

                using (MySqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        string eventName = reader["title"].ToString();
                        comboBoxEvents.Items.Add(eventName);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading events: {ex.Message}");
            }
            finally
            {
                connection.Close();
            }
        }


        private void LoadMembers()
        {
            try
            {
                connection.Open();
                string query = "SELECT Users.email " +
                               "FROM Users " +
                               "INNER JOIN SocietyMemberships ON Users.user_id = SocietyMemberships.user_id " +
                               "INNER JOIN Societies ON SocietyMemberships.society_id = Societies.society_id " +
                               "INNER JOIN SocietyMemberships AS UserMembership ON UserMembership.society_id = Societies.society_id " +
                               "INNER JOIN Users AS CurrentUser ON UserMembership.user_id = CurrentUser.user_id " +
                               "WHERE (Users.role = 'member' OR Users.role = 'head') AND CurrentUser.email = @UserEmail";
                MySqlCommand command = new MySqlCommand(query, connection);
                command.Parameters.AddWithValue("@UserEmail", userEmail);

                using (MySqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        string memberEmail = reader["email"].ToString();
                        comboBoxMembers.Items.Add(memberEmail);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading members: {ex.Message}");
            }
            finally
            {
                connection.Close();
            }
        }



        private void btnSubmit_Click(object sender, EventArgs e)
        {
            string selectedEvent = comboBoxEvents.SelectedItem?.ToString();
            string selectedMember = comboBoxMembers.SelectedItem?.ToString();
            string taskDescription = txtTaskDescription.Text.Trim();
            string taskDetails = txtTaskDetails.Text.Trim();

            if (string.IsNullOrEmpty(selectedEvent) || string.IsNullOrEmpty(selectedMember) || string.IsNullOrEmpty(taskDescription))
            {
                MessageBox.Show("Please select an event, member, and enter task description.");
                return;
            }

            try
            {
                connection.Open();
                string query = "INSERT INTO Tasks (society_id, assigned_to, description, details) " +
                               "VALUES ((SELECT Societies.society_id " +
                                        "FROM Events " +
                                        "INNER JOIN Societies ON Events.society_id = Societies.society_id " +
                                        "WHERE Events.title = @EventTitle), " +
                                       "(SELECT user_id FROM Users WHERE email = @MemberEmail), " +
                                       "@Description, @Details)";
                MySqlCommand command = new MySqlCommand(query, connection);
                command.Parameters.AddWithValue("@MemberEmail", selectedMember);
                command.Parameters.AddWithValue("@EventTitle", selectedEvent);
                command.Parameters.AddWithValue("@Description", taskDescription);
                command.Parameters.AddWithValue("@Details", taskDetails);
                int rowsAffected = command.ExecuteNonQuery();
                if (rowsAffected > 0)
                {
                    MessageBox.Show("Task assigned successfully.");
                }
                else
                {
                    MessageBox.Show("Failed to assign task.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error assigning task: {ex.Message}");
            }
            finally
            {
                connection.Close();
            }
        }



    }
}
