﻿using System;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace se
{

    public partial class FeedbackForm : Form
    {

        private TextBox feedbackTextBox;
        private ComboBox categoryDropdown; // First dropdown for categories
        private ComboBox typeDropdown; // Second dropdown for types
        private Button submitButton;
        //private int eventId; // Event ID (commented out as it's not used in your current code)
        private int userId; // User ID

        public FeedbackForm(int userId)
        {
            InitializeComponent();
            this.userId = userId;
            InitializeControls();
        }

        private void InitializeControls()
        {
            // Initialize feedbackTextBox
            feedbackTextBox = new TextBox
            {
                Multiline = true,
                WordWrap = true,
                Size = new System.Drawing.Size(300, 200),
                Location = new System.Drawing.Point(50, 100) // Adjust location to make room for dropdowns
            };

            // Initialize categoryDropdown (for societies)
            categoryDropdown = new ComboBox
            {
                DropDownStyle = ComboBoxStyle.DropDownList,
                Location = new System.Drawing.Point(50, 50),
                Size = new System.Drawing.Size(300, 21)
            };
            PopulateSocietiesDropdown(); // Populate dropdown with society names
            categoryDropdown.SelectedIndexChanged += CategoryDropdown_SelectedIndexChanged;


            // Initialize typeDropdown
            typeDropdown = new ComboBox
            {
                DropDownStyle = ComboBoxStyle.DropDownList,
                Location = new System.Drawing.Point(50, 75), // Place it below the first dropdown
                Size = new System.Drawing.Size(300, 21)
            };
            // Assume typeDropdown items are populated elsewhere or manually as shown in previous example

            // Initialize submitButton
            submitButton = new Button
            {
                Text = "Submit",
                Location = new System.Drawing.Point(150, 320), // Adjust location according to the new controls
                Size = new System.Drawing.Size(100, 30)
            };
            submitButton.Click += SubmitButton_Click;

            // Add controls to the form
            Controls.Add(categoryDropdown);
            Controls.Add(typeDropdown);
            Controls.Add(feedbackTextBox);
            Controls.Add(submitButton);
        }

        private void PopulateSocietiesDropdown()
        {
            string connectionString = "server=localhost;database=se;uid=root;pwd=1234567;"; // Modify connection string as needed
                                                                                            // Modified query to exclude the societies the user belongs to
            string query = @"
        SELECT name 
        FROM Societies 
        WHERE society_id NOT IN (
            SELECT society_id 
            FROM SocietyMemberships 
            WHERE user_id = @userId
        )
        ORDER BY name ASC;";

            using (var connection = new MySqlConnection(connectionString))
            {
                using (var cmd = new MySqlCommand(query, connection))
                {
                    cmd.Parameters.AddWithValue("@userId", userId); // Use the userId field to filter out societies
                    try
                    {
                        connection.Open();
                        using (var reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                categoryDropdown.Items.Add(reader["name"].ToString());
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("An error occurred while fetching society names: " + ex.Message);
                    }
                }
            }
        }
        private void CategoryDropdown_SelectedIndexChanged(object sender, EventArgs e)
        {
            typeDropdown.Items.Clear(); // Clear previous items

            if (categoryDropdown.SelectedIndex < 0) return; // No society selected

            string selectedSocietyName = categoryDropdown.SelectedItem.ToString();
            PopulateEventsDropdown(selectedSocietyName);
        }

        private void PopulateEventsDropdown(string societyName)
        {
            string connectionString = "server=localhost;database=se;uid=root;pwd=1234567;"; // Modify as needed

            string query = @"
        SELECT e.title 
        FROM Events e
        JOIN Societies s ON e.society_id = s.society_id
        WHERE s.name = @societyName
        ORDER BY e.title ASC;";

            using (var connection = new MySqlConnection(connectionString))
            {
                using (var cmd = new MySqlCommand(query, connection))
                {
                    cmd.Parameters.AddWithValue("@societyName", societyName); // Filter events by society name
                    try
                    {
                        connection.Open();
                        using (var reader = cmd.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                typeDropdown.Items.Add(reader["title"].ToString());
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("An error occurred while fetching event names: " + ex.Message);
                    }
                }
            }
        }


        private void SubmitButton_Click(object sender, EventArgs e)
        {
            // Get the feedback and selected dropdown values
            string feedback = feedbackTextBox.Text;
            string category = categoryDropdown.SelectedItem.ToString();
            string type = typeDropdown.SelectedItem.ToString();

            // Validate if feedback and selections are provided
            if (string.IsNullOrWhiteSpace(feedback) || categoryDropdown.SelectedIndex < 0 || typeDropdown.SelectedIndex < 0)
            {
                MessageBox.Show("Please provide your feedback and select options before submitting.");
                return;
            }

            // Assuming you want to insert category and type along with feedback into the database
            InsertFeedbackIntoDatabase(feedback, type, category);

            // Close the form
            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        private void InsertFeedbackIntoDatabase(string feedback, string eventName, string societyName)
        {
            string connectionString = "server=localhost;database=se;uid=root;pwd=1234567;";

            // Assume societyName and eventName are used to find the correct event_id
            // First, find the event_id for the given eventName within the selected society
            int societyID = GetSocietyIdByName(societyName);
            int eventId = GetEventId(eventName, societyID, connectionString);

            if (eventId == -1)
            {
                MessageBox.Show("Event not found.");
                return;
            }

            using (var connection = new MySqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    string query = "INSERT INTO Feedbacks (event_id, content, provided_by) VALUES (@event_id, @content, @provided_by)";

                    using (var cmd = new MySqlCommand(query, connection))
                    {
                        cmd.Parameters.AddWithValue("@event_id", eventId);
                        cmd.Parameters.AddWithValue("@content", feedback);
                        cmd.Parameters.AddWithValue("@provided_by", userId);
                        cmd.ExecuteNonQuery();
                    }

                    MessageBox.Show("Feedback submitted successfully.");
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error submitting feedback: {ex.Message}");
                }
            }
        }
        private int GetSocietyIdByName(string societyName)
        {
            string connectionString = "server=localhost;database=se;uid=root;pwd=1234567;";
            int societyId = -1; // Initialize with a default value indicating not found

            using (var connection = new MySqlConnection(connectionString))
            {
                // Prepare the SQL query to fetch the society_id
                string query = "SELECT society_id FROM Societies WHERE name = @SocietyName LIMIT 1";
                using (var cmd = new MySqlCommand(query, connection))
                {
                    // Use parameterized query to prevent SQL injection
                    cmd.Parameters.AddWithValue("@SocietyName", societyName);
                    try
                    {
                        connection.Open();
                        var result = cmd.ExecuteScalar(); // Execute the query and get the result

                        if (result != null)
                        {
                            societyId = Convert.ToInt32(result); // Convert the result to int and assign to societyId
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Error fetching society ID: {ex.Message}");
                    }
                }
            }

            return societyId; // Return the found society ID, or -1 if not found
        }

        // Utility method to find the event_id based on eventName and societyName
        private int GetEventId(string eventName, int societyId, string connectionString)
        {
            using (var connection = new MySqlConnection(connectionString))
            {
                // Correct the SQL query to use the society_id directly
                string query = @"
        SELECT e.event_id 
        FROM Events e
        WHERE e.title = @eventName AND e.society_id = @SocietyId LIMIT 1";

                using (var cmd = new MySqlCommand(query, connection))
                {
                    // Properly define and add the parameters for eventName and societyId
                    cmd.Parameters.AddWithValue("@eventName", eventName);
                    cmd.Parameters.AddWithValue("@SocietyId", societyId);
                    connection.Open();

                    var result = cmd.ExecuteScalar();
                    if (result != null)
                    {
                        return Convert.ToInt32(result);
                    }
                }
            }

            return -1; // Indicates not found
        }

        private void FeedbackForm_Load(object sender, EventArgs e)
        {
            // Your code here, for example:
            // MessageBox.Show("FeedbackForm is loading");
        }

    }

}
