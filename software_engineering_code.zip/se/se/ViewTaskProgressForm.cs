﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace se
{
    public partial class ViewTaskProgressForm : Form
    {
        private string userEmail; // Add a field to store the user email

        // Update the constructor to accept the userEmail parameter
        public ViewTaskProgressForm(string userEmail)
        {
            InitializeComponent();
            this.userEmail = userEmail; // Store the userEmail in the field
            LoadTaskProgress(); // Load task progress when the form is initialized
        }

        private void ViewTaskProgressForm_Load(object sender, EventArgs e)
        {
            // Load any necessary data or perform initialization
        }

        private void LoadTaskProgress()
        {
            try
            {
                string connectionString = "server=localhost;database=se;uid=root;pwd=1234567;";
                using (MySqlConnection connection = new MySqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT Tasks.description, Users.email AS member_email, Tasks.progress " +
                                   "FROM Tasks " +
                                   "INNER JOIN Users ON Tasks.assigned_to = Users.user_id " +
                                   "INNER JOIN SocietyMemberships ON Users.user_id = SocietyMemberships.user_id " +
                                   "WHERE SocietyMemberships.society_id = (SELECT society_id FROM SocietyMemberships WHERE user_id = (SELECT user_id FROM Users WHERE email = @UserEmail)) OR Users.role='head'";
                    MySqlCommand command = new MySqlCommand(query, connection);
                    command.Parameters.AddWithValue("@UserEmail", userEmail);

                    using (MySqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            string taskDescription = reader["description"].ToString();
                            string memberEmail = reader["member_email"].ToString();
                            string progressStr = reader["progress"].ToString();

                            // Extract numerical value from progress string
                            if (progressStr.EndsWith("%"))
                            {
                                progressStr = progressStr.Substring(0, progressStr.Length - 1); // Remove '%' symbol
                            }

                            // Check if progressStr is a valid integer
                            if (int.TryParse(progressStr, out int progress))
                            {
                                // Create a label to display task information
                                Label taskLabel = new Label
                                {
                                    Text = $"Task: {taskDescription} | Assigned to: {memberEmail} | Progress: {progress}%",
                                    AutoSize = true,
                                    Location = new Point(20, 20 + (tasksPanel.Controls.Count * 30)), // Adjust Y position dynamically
                                };

                                tasksPanel.Controls.Add(taskLabel); // Add the label to the panel
                            }
                            else
                            {
                                // Handle the case where progressStr is not a valid integer
                                MessageBox.Show($"Invalid progress value: {reader["progress"].ToString()}");
                            }
                        }


                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading task progress: {ex.Message}");
            }
        }
    }
}
