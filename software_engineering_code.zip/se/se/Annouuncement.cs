﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;


namespace se
{
    public partial class Form2 : Form
    {
        private string userEmail;
        private string userRole;
        private string userId;
        private LoginForm loginForm; // Declare an instance of LoginForm

        public Form2(string email, string role, string userId, LoginForm loginForm)
        {
            InitializeComponent();
            userEmail = email;
            userRole = role;
            this.userId = userId;

            this.loginForm = loginForm; // Create an instance of LoginForm
            CustomizeComponents(); // Pass the loginForm instance to CustomizeComponents
        }

        private void CustomizeComponents() // Accept the loginForm instance as a parameter
        {
            // Example of setting the title, email, and role
            this.Text = "Announcements - FASTies";
            Label emailLabel = new Label()
            {
                Text = "Email: " + userEmail,
                AutoSize = true,
                Location = new Point(10, 10) // Adjust as needed
            };
            Label roleLabel = new Label()
            {
                Text = "Role: " + userRole,
                AutoSize = true,
                Location = new Point(10, 30) // Adjust as needed
            };
            this.Controls.Add(emailLabel);
            this.Controls.Add(roleLabel);
            this.Controls.Add(announcementsListBox);
            LoadAnnouncements();
            AddRoleSpecificButtons(); // Pass the loginForm instance to AddRoleSpecificButtons
        }

        private void AddRoleSpecificButtons() 
        {
            Dictionary<string, string[]> buttonTextsByRole = new Dictionary<string, string[]>
    {
            { "mentor", new string[] { "Society Management", "Assign Tasks", "Update Society Heads", "Private Message", "View Task Progress", "Logout" } },
            { "head", new string[] { "Register Event", "Check Status", "Update Task", "Leave Society", "Private Message", "Logout" } },
            { "member", new string[] { "Task Update", "Leave Society", "Update Task", "Logout" } }
    };

            if (buttonTextsByRole.ContainsKey(userRole.ToLower()))
            {
                int yPos = 300;
                foreach (var buttonText in buttonTextsByRole[userRole.ToLower()])
                {
                    Button roleButton = new Button
                    {
                        Text = buttonText,
                        Location = new Point(100, yPos),
                        Size = new Size(300, 40),
                        BackColor = Color.Black,
                        ForeColor = Color.White,
                        FlatStyle = FlatStyle.Flat
                    };

                    // Add a click event for each button based on its text
                    roleButton.Click += (sender, e) =>
                    {
                        switch (buttonText)
                        {
                            case "Private Message":
                                if (userRole.ToLower() == "head" || userRole.ToLower() == "mentor")
                                {
                                    PrivateMessageForm privateMessageForm = new PrivateMessageForm(userEmail, userRole);
                                    privateMessageForm.Show();
                                }
                                break;
                            case "Register Event":
                                if (userRole.ToLower() == "head")
                                {
                                    OpenRegisterEventForm();
                                }
                                break;
                            case "Check Status":
                                if (userRole.ToLower() == "head")
                                {
                                    EventStatusForm statusForm = new EventStatusForm(userEmail);
                                    statusForm.Show();
                                }
                                break;
                            case "Society Management":
                                if (userRole.ToLower() == "mentor")
                                {
                                    SocietyManagementForm managementForm = new SocietyManagementForm();
                                    managementForm.Show();
                                }
                                break;
                            case "Assign Tasks": // Add case for "Assign Tasks"
                                if (userRole.ToLower() == "mentor")
                                {
                                    AssignTasksForm assignTasksForm = new AssignTasksForm(userEmail);
                                    assignTasksForm.Show();
                                }
                                break;
                            case "Update Task": // Add case for "Update Task"
                                if (userRole.ToLower() == "member" || userRole.ToLower() == "head")
                                {
                                    UpdateTaskForm updateTaskForm = new UpdateTaskForm(userEmail);
                                    updateTaskForm.Show();
                                }
                                break;
                            case "View Task Progress": // Add case for "View Task Progress"
                                if (userRole.ToLower() == "mentor")
                                {
                                    ViewTaskProgressForm viewTaskProgressForm = new ViewTaskProgressForm(userEmail);
                                    viewTaskProgressForm.Show();
                                }
                                break;
                            case "Update Society Heads":
                                if (userRole.ToLower() == "mentor")
                                {
                                    UpdateSocietyHeadsForm updateSocietyHeadsForm = new UpdateSocietyHeadsForm(userEmail);
                                    updateSocietyHeadsForm.Show();
                                }
                                break;
                            case "Leave Society":
                                if (userRole.ToLower() == "member" || userRole.ToLower() == "head")
                                {
                                    DialogResult result = MessageBox.Show("Are you sure you want to leave the society?", "Leave Society", MessageBoxButtons.YesNo);
                                    if (result == DialogResult.Yes)
                                    {
                                        // Delete the member from the society's database record
                                        DeleteMemberFromSociety();
                                        MessageBox.Show("You have left the society successfully.");

                                        // Show the LoginForm instance
                                        loginForm.Show();
                                        // Close the current form
                                        this.Hide();
                                    }
                                }
                                break;
                            case "Logout": // Add case for "Logout"
                                if (userRole.ToLower() == "mentor" || userRole.ToLower() == "member" || userRole.ToLower() == "head")
                                {
                                    MessageBox.Show("Logout Successful");
                                    // Show the LoginForm instance
                                    loginForm.Show();
                                    // Close the current form
                                    this.Hide();

                                   
                                }
                                break;
                        }
                    };

                    Button feedbackButton = new Button
                    {
                        Text = "Give Feedback",
                        Location = new Point(100, 250), // Adjust the Y position as needed
                        Size = new Size(300, 40),
                        BackColor = Color.Black,
                        ForeColor = Color.White,
                        FlatStyle = FlatStyle.Flat
                    };
                    feedbackButton.Click += (sender, e) => OpenFeedbackForm();
                    this.Controls.Add(feedbackButton);
                    this.Controls.Add(roleButton);
                    yPos += 50; // Increment for the next button's Y position
                }
                Button viewFeedbackButton = new Button
                {
                    Text = "View Feedback",
                    Location = new Point(100, yPos), // Correctly set the location using yPos
                    Size = new Size(300, 40),
                    BackColor = Color.Black,
                    ForeColor = Color.White,
                    FlatStyle = FlatStyle.Flat
                };
                viewFeedbackButton.Click += ViewFeedbackButton_Click;
                this.Controls.Add(viewFeedbackButton);
            }
        }


        private void DeleteMemberFromSociety()
        {
            string connectionString = "server=localhost;database=se;uid=root;pwd=1234567;";
            using (MySqlConnection con = new MySqlConnection(connectionString))
            {
                try
                {
                    con.Open();
                    string sql = "DELETE FROM SocietyMemberships WHERE user_id = @userId";
                    MySqlCommand cmd = new MySqlCommand(sql, con);
                    cmd.Parameters.AddWithValue("@userId", userId);
                    cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error deleting member from society: {ex.Message}");
                }
            }
        }
        private void OpenFeedbackForm()
        {
            // Convert userId to integer if necessary, assuming FeedbackForm expects an integer
            int id;

            if (int.TryParse(userId, out id))
            {
                FeedbackForm feedbackForm = new FeedbackForm(id); // Pass userId to the constructor
                feedbackForm.Show();
            }
            else
            {
                MessageBox.Show("Invalid UserId");
            }
        }
        private void ViewFeedbackButton_Click(object sender, EventArgs e)
        {
            int id;

            if (int.TryParse(userId, out id))
            {
                FeedbackViewForm feedbackViewForm = new FeedbackViewForm(id);
                feedbackViewForm.Show();
            }
            else
            {
                MessageBox.Show("Invalid UserId");
            }

        }

        private void OpenRegisterEventForm()
        {
            // Assuming RegisterEventForm is the form you create for event registration
            RegisterEventForm registerEventForm = new RegisterEventForm(userEmail);
            registerEventForm.Show();
        }

        private void LoadAnnouncements()
        {
            string connectionString = "server=localhost;database=se;uid=root;pwd=1234567;";
            using (MySqlConnection con = new MySqlConnection(connectionString))
            {
                try
                {
                    con.Open();
                    string sql = "SELECT content FROM Announcements WHERE visible_to_all = TRUE ORDER BY announcement_id";
                    MySqlCommand cmd = new MySqlCommand(sql, con);
                    using (MySqlDataReader reader = cmd.ExecuteReader())
                    {
                        int announcementNumber = 1; // Start counting from 1
                        while (reader.Read())
                        {
                            string announcement = reader["content"].ToString();
                            // Prefix each announcement with its number
                            string formattedAnnouncement = $"Announcement {announcementNumber}: {announcement}";
                            announcementsListBox.Items.Add(formattedAnnouncement);
                            announcementNumber++; // Increment the counter for each announcement
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error loading announcements: {ex.Message}");
                }
            }
        }

        private void announcementsListBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }
    }
}
