﻿namespace se
{
    partial class AssignTasksForm
    {
        private System.Windows.Forms.ComboBox comboBoxEvents;
        private System.Windows.Forms.ComboBox comboBoxMembers;
        private System.Windows.Forms.TextBox txtTaskDescription;
        private System.Windows.Forms.TextBox txtTaskDetails;
        private System.Windows.Forms.Button btnSubmit;
        private System.Windows.Forms.Label lblEvent;
        private System.Windows.Forms.Label lblMember;
        private System.Windows.Forms.Label lblDescription;
        private System.Windows.Forms.Label lblDetails;

        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.SuspendLayout();
            // 
            // AssignTasksForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Name = "AssignTasksForm";
            this.Text = "AssignTasksForm";
            this.Load += new System.EventHandler(this.AssignTasksForm_Load);
            this.ResumeLayout(false);
            // Initialize lblEvent
            this.lblEvent = new System.Windows.Forms.Label();
            this.lblEvent.AutoSize = true;
            this.lblEvent.Location = new System.Drawing.Point(20, 50);
            this.lblEvent.Text = "Select Event";
            this.Controls.Add(this.lblEvent); // Add lblEvent to the form's controls

            // Initialize comboBoxEvents
            this.comboBoxEvents = new System.Windows.Forms.ComboBox();
            this.comboBoxEvents.FormattingEnabled = true;
            this.comboBoxEvents.Location = new System.Drawing.Point(150, 50); // Adjust the location as needed
            this.comboBoxEvents.Size = new System.Drawing.Size(200, 25); // Adjust the size as needed
            this.Controls.Add(this.comboBoxEvents); // Add comboBoxEvents to the form's controls

            // Initialize lblMember
            this.lblMember = new System.Windows.Forms.Label();
            this.lblMember.AutoSize = true;
            this.lblMember.Location = new System.Drawing.Point(20, 100);
            this.lblMember.Text = "Select Member";
            this.Controls.Add(this.lblMember); // Add lblMember to the form's controls

            // Initialize comboBoxMembers
            this.comboBoxMembers = new System.Windows.Forms.ComboBox();
            this.comboBoxMembers.FormattingEnabled = true;
            this.comboBoxMembers.Location = new System.Drawing.Point(150, 100); // Adjust the location as needed
            this.comboBoxMembers.Size = new System.Drawing.Size(200, 25); // Adjust the size as needed
            this.Controls.Add(this.comboBoxMembers); // Add comboBoxMembers to the form's controls

            // Initialize lblDescription
            this.lblDescription = new System.Windows.Forms.Label();
            this.lblDescription.AutoSize = true;
            this.lblDescription.Location = new System.Drawing.Point(20, 150);
            this.lblDescription.Text = "Task Description";
            this.Controls.Add(this.lblDescription); // Add lblDescription to the form's controls

            // Initialize txtTaskDescription
            this.txtTaskDescription = new System.Windows.Forms.TextBox();
            this.txtTaskDescription.Location = new System.Drawing.Point(150, 150); // Adjust the location as needed
            this.txtTaskDescription.Size = new System.Drawing.Size(300, 50); // Adjust the size as needed
            this.txtTaskDescription.Multiline = true; // Allow multiline input
            this.Controls.Add(this.txtTaskDescription); // Add txtTaskDescription to the form's controls

            // Initialize lblDetails
            this.lblDetails = new System.Windows.Forms.Label();
            this.lblDetails.AutoSize = true;
            this.lblDetails.Location = new System.Drawing.Point(20, 210);
            this.lblDetails.Text = "Task Detail";
            this.Controls.Add(this.lblDetails); // Add lblDetails to the form's controls

            // Initialize txtTaskDetails
            this.txtTaskDetails = new System.Windows.Forms.TextBox();
            this.txtTaskDetails.Location = new System.Drawing.Point(150, 210); // Adjust the location as needed
            this.txtTaskDetails.Size = new System.Drawing.Size(300, 50); // Adjust the size as needed
            this.txtTaskDetails.Multiline = true; // Allow multiline input
            this.Controls.Add(this.txtTaskDetails); // Add txtTaskDetails to the form's controls

            // Initialize btnSubmit
            this.btnSubmit = new System.Windows.Forms.Button();
            this.btnSubmit.Location = new System.Drawing.Point(150, 280); // Adjust the location as needed
            this.btnSubmit.Size = new System.Drawing.Size(100, 30); // Adjust the size as needed
            this.btnSubmit.Text = "Submit"; // Set the button text
            this.btnSubmit.Click += new System.EventHandler(this.btnSubmit_Click); // Add click event handler
            this.Controls.Add(this.btnSubmit); // Add btnSubmit to the form's controls
        }

        #endregion
    }
}
