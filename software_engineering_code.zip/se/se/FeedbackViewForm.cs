﻿using MySql.Data.MySqlClient;
using System;
using System.Windows.Forms;

namespace se
{
    public partial class FeedbackViewForm : Form
    {
        private int userId;

        public FeedbackViewForm(int userId)
        {
            InitializeComponent();
            this.userId = userId;
            LoadFeedback(); // Load feedback when the form is initialized
        }

        public FeedbackViewForm()
        {
            InitializeComponent();
        }

        private void LoadFeedback()
        {
            string connectionString = "server=localhost;database=se;uid=root;pwd=1234567;";
            using (MySqlConnection connection = new MySqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    string query = @"
                        SELECT f.content
                        FROM se.Feedbacks f
                        INNER JOIN se.Events e ON f.event_id = e.event_id
                        INNER JOIN se.SocietyMemberships sm ON e.society_id = sm.society_id
                        WHERE sm.user_id = @UserId
                        ORDER BY f.feedback_id ASC";
                    MySqlCommand command = new MySqlCommand(query, connection);
                    command.Parameters.AddWithValue("@UserId", userId);

                    using (MySqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            string feedbackContent = reader["content"].ToString();
                            feedbackListBox.Items.Add(feedbackContent);
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error loading feedbacks: {ex.Message}");
                }
            }
        }
        private void FeedbackViewForm_Load(object sender, EventArgs e)
        {
            // This method is required by the Designer to wire up the form load event.
            // You can leave it empty if you don't have any specific initialization logic here.
        }

        private void feedbackListBox_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }

}
