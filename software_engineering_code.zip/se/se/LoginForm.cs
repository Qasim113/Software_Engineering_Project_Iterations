﻿using System;
using System.Drawing;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace se
{
    public partial class LoginForm : Form
    {
        private TextBox usernameTextBox;
        private TextBox passwordTextBox;
        private Button loginButton;
        private Label headerLabel;

        public bool IsLoggedIn { get; private set; } // New property to track login status
        public string UserEmail { get; private set; } // New property to store user email
        public string UserRole { get; private set; } // New property to store user role
        public string UserId { get; private set; } // New property to store user ID

        public LoginForm()
        {
            InitializeComponent();
            CustomizeComponents();
            IsLoggedIn = false; // Initially set to false
        }

        private void CustomizeComponents()
        {
            // Set the form's background color
            this.BackColor = Color.DarkGray;

            // Initialize the header label for "FASTies"
            headerLabel = new Label();
            headerLabel.Text = "FASTies";
            headerLabel.Font = new Font("Arial", 24, FontStyle.Bold);
            headerLabel.ForeColor = Color.White;
            headerLabel.AutoSize = true;
            headerLabel.Location = new Point((this.Width - headerLabel.Width) / 2, 50);

            // Adjusting properties of usernameTextBox
            usernameTextBox.BackColor = Color.LightGray;
            usernameTextBox.ForeColor = Color.Black;
            usernameTextBox.BorderStyle = BorderStyle.FixedSingle;
            usernameTextBox.Location = new Point((this.Width - usernameTextBox.Width) / 2, 200);

            // Adjusting properties of passwordTextBox
            passwordTextBox.BackColor = Color.LightGray;
            passwordTextBox.ForeColor = Color.Black;
            passwordTextBox.BorderStyle = BorderStyle.FixedSingle;
            passwordTextBox.Location = new Point((this.Width - passwordTextBox.Width) / 2, 240);

            // Adjusting properties of loginButton
            loginButton.BackColor = Color.LightSlateGray;
            loginButton.ForeColor = Color.White;
            loginButton.FlatStyle = FlatStyle.Flat;
            loginButton.Location = new Point((this.Width - loginButton.Width) / 2, 290);

            // Add the controls to the form
            this.Controls.Add(headerLabel);
            this.Controls.Add(usernameTextBox);
            this.Controls.Add(passwordTextBox);
            this.Controls.Add(loginButton);

            // Center the form on the screen
            this.StartPosition = FormStartPosition.CenterScreen;
        }

        private void loginButton_Click(object sender, EventArgs e)
        {
            string connectionString = "server=localhost;database=se;uid=root;pwd=1234567;";
            using (MySqlConnection con = new MySqlConnection(connectionString))
            {
                try
                {
                    con.Open();
                    // Updated SQL query to check if the user is part of any societies
                    string sql = @"
                SELECT u.user_id, u.email, u.role
                FROM Users u
                WHERE u.email = @username AND u.password = @password
                AND EXISTS (
                    SELECT 1 FROM SocietyMemberships sm
                    WHERE sm.user_id = u.user_id
                );";

                    MySqlCommand cmd = new MySqlCommand(sql, con);
                    cmd.Parameters.AddWithValue("@username", usernameTextBox.Text);
                    cmd.Parameters.AddWithValue("@password", passwordTextBox.Text);
                    MySqlDataReader reader = cmd.ExecuteReader();

                    if (reader.Read())
                    {
                        MessageBox.Show("Login Successful");
                        UserEmail = reader["email"].ToString();
                        UserRole = reader["role"].ToString();
                        UserId = reader.GetInt32("user_id").ToString();
                        IsLoggedIn = true; // Set IsLoggedIn to true

                        this.Hide();

                        // Create an instance of Form2 and pass the current LoginForm instance
                        Form2 announcementsForm = new Form2(UserEmail, UserRole, UserId, this);
                        announcementsForm.ShowDialog();
                    }
                    else
                    {
                        // If no rows are returned, it means either credentials are wrong or user isn't part of any society
                        MessageBox.Show(" Wrong email or password or You are not in any societies; therefore, you cannot log in. Please refer to the Academic Office.");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error: {ex.Message}");
                }
            }
        }

        private void LoginForm_Load(object sender, EventArgs e)
        {
            // No implementation needed
        }
    }
}