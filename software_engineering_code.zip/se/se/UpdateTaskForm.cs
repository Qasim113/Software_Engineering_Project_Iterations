﻿using MySql.Data.MySqlClient;
using System.Windows.Forms;
using System;

namespace se
{
    public partial class UpdateTaskForm : Form
    {
        private string userEmail;

        public UpdateTaskForm(string userEmail)
        {
            InitializeComponent();
            this.userEmail = userEmail;
            LoadAssignedTasks();
        }

        private void UpdateTaskForm_Load(object sender, EventArgs e)
        {
            // Load any necessary data or perform initialization
        }

        private void LoadAssignedTasks()
        {
            comboBoxTasks.Items.Clear();
            try
            {
                string connectionString = "server=localhost;database=se;uid=root;pwd=1234567;";
                using (MySqlConnection connection = new MySqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "SELECT description FROM Tasks " +
                                   "INNER JOIN Users ON Tasks.assigned_to = Users.user_id " +
                                   "WHERE Users.email = @UserEmail OR Users.role = 'head'";
                    MySqlCommand command = new MySqlCommand(query, connection);
                    command.Parameters.AddWithValue("@UserEmail", userEmail);

                    using (MySqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            string taskDescription = reader["description"].ToString();
                            comboBoxTasks.Items.Add(taskDescription);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading assigned tasks: {ex.Message}");
            }
        }

        private void btnCompleted30_Click(object sender, EventArgs e)
        {
            // Update the task status to 30% completed
            UpdateTaskStatus("30%");
        }

        private void btnCompleted70_Click(object sender, EventArgs e)
        {
            // Update the task status to 70% completed
            UpdateTaskStatus("70%");
        }

        private void btnCompleted100_Click(object sender, EventArgs e)
        {
            // Update the task status to 100% completed
            UpdateTaskStatus("100%");
        }

        private void UpdateTaskStatus(string status)
        {
            string selectedTask = comboBoxTasks.SelectedItem?.ToString();
            if (string.IsNullOrEmpty(selectedTask))
            {
                MessageBox.Show("Please select a task.");
                return;
            }

            try
            {
                string connectionString = "server=localhost;database=se;uid=root;pwd=1234567;";
                using (MySqlConnection connection = new MySqlConnection(connectionString))
                {
                    connection.Open();
                    string query = "UPDATE Tasks SET progress = @Progress WHERE description = @Description";
                    MySqlCommand command = new MySqlCommand(query, connection);
                    command.Parameters.AddWithValue("@Progress", status);
                    command.Parameters.AddWithValue("@Description", selectedTask);
                    int rowsAffected = command.ExecuteNonQuery();
                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Task status updated successfully.");
                        LoadAssignedTasks(); // Reload assigned tasks after updating
                    }
                    else
                    {
                        MessageBox.Show("Failed to update task status.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error updating task status: {ex.Message}");
            }
        }
    }
}
