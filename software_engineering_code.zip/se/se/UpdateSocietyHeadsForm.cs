﻿using System;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace se
{
    public partial class UpdateSocietyHeadsForm : Form
    {
        private MySqlConnection connection;
        private string userEmail;
        private ComboBox comboBoxHeads;
        private Button btnSubmit;

        public UpdateSocietyHeadsForm(string userEmail)
        {
            InitializeComponent();
            this.userEmail = userEmail;
            InitializeDatabaseConnection();
            LoadHeads();
        }

        private void InitializeComponent()
        {
            this.comboBoxHeads = new ComboBox();
            this.btnSubmit = new Button();

            // Set form properties and layout

            // comboBoxHeads
            this.comboBoxHeads.DropDownStyle = ComboBoxStyle.DropDownList;
            this.comboBoxHeads.FormattingEnabled = true;
            this.comboBoxHeads.Location = new System.Drawing.Point(12, 12);
            this.comboBoxHeads.Name = "comboBoxHeads";
            this.comboBoxHeads.Size = new System.Drawing.Size(200, 21);
            this.comboBoxHeads.TabIndex = 0;

            // btnSubmit
            this.btnSubmit.Location = new System.Drawing.Point(12, 50);
            this.btnSubmit.Name = "btnSubmit";
            this.btnSubmit.Size = new System.Drawing.Size(75, 23);
            this.btnSubmit.TabIndex = 1;
            this.btnSubmit.Text = "Submit";
            this.btnSubmit.UseVisualStyleBackColor = true;
            this.btnSubmit.Click += new EventHandler(btnSubmit_Click);

            // Add controls to the form
            this.Controls.Add(this.comboBoxHeads);
            this.Controls.Add(this.btnSubmit);
        }

        private void InitializeDatabaseConnection()
        {
            string connectionString = "server=localhost;database=se;uid=root;pwd=1234567;";
            connection = new MySqlConnection(connectionString);
        }

        private void LoadHeads()
        {
            try
            {
                connection.Open();
                string query = "SELECT email " +
                               "FROM Users " +
                               "WHERE role = 'head' " +
                               "AND user_id NOT IN " +
                               "(SELECT user_id FROM SocietyMemberships)";
                MySqlCommand command = new MySqlCommand(query, connection);

                using (MySqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        string headEmail = reader["email"].ToString();
                        comboBoxHeads.Items.Add(headEmail);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading heads: {ex.Message}");
            }
            finally
            {
                connection.Close();
            }
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            string selectedHead = comboBoxHeads.SelectedItem?.ToString();

            if (string.IsNullOrEmpty(selectedHead))
            {
                MessageBox.Show("Please select a head.");
                return;
            }

            try
            {
                connection.Open();
                string updateQuery = "UPDATE Societies " +
                                     "SET mentor_id = (SELECT user_id FROM Users WHERE email = @NewHeadEmail) " +
                                     "WHERE society_id = " +
                                     "(SELECT society_id FROM SocietyMemberships " +
                                     "WHERE user_id = " +
                                     "(SELECT user_id FROM Users WHERE email = @UserEmail))";
                MySqlCommand updateCommand = new MySqlCommand(updateQuery, connection);
                updateCommand.Parameters.AddWithValue("@NewHeadEmail", selectedHead);
                updateCommand.Parameters.AddWithValue("@UserEmail", userEmail);
                int rowsAffected = updateCommand.ExecuteNonQuery();
                if (rowsAffected > 0)
                {
                    MessageBox.Show("Head updated successfully.");
                }
                else
                {
                    MessageBox.Show("Failed to update head.");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error updating head: {ex.Message}");
            }
            finally
            {
                connection.Close();
            }
        }
    }
}