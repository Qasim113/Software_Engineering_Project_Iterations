﻿using System;
using System.Data;
using System.Linq;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Collections.Generic;

public class PrivateMessageForm : Form
{
    private string userEmail;
    private string userRole;
    private TextBox messageContent;
    private Button submitButton;
    private ListBox messagesListBox; // To display past messages

    public PrivateMessageForm(string email, string role)
    {
        userEmail = email;
        userRole = role;
        InitializeForm();
        LoadPastMessages(); // Load past messages on form initialization
    }

    private void InitializeForm()
    {
        this.Text = "Private Message";
        this.Width = 600; // Increased width to accommodate message list
        this.Height = 500;

        messagesListBox = new ListBox()
        {
            Width = 500,
            Height = 200,
            Location = new System.Drawing.Point(50, 20)
        };

        messageContent = new TextBox
        {
            Multiline = true,
            Width = 500,
            Height = 100,
            Location = new System.Drawing.Point(50, 230) // Adjusted location
        };

        submitButton = new Button
        {
            Text = "Send",
            Location = new System.Drawing.Point(250, 340), // Adjusted location
            Width = 100
        };
        submitButton.Click += SubmitButton_Click;

        this.Controls.Add(messagesListBox);
        this.Controls.Add(messageContent);
        this.Controls.Add(submitButton);
    }

    private void SubmitButton_Click(object sender, EventArgs e)
    {
        string message = messageContent.Text;
        if (!string.IsNullOrWhiteSpace(message))
        {
            PostPrivateMessage(message);
            LoadPastMessages(); // Reload messages to include the new one
        }
        else
        {
            MessageBox.Show("Please enter a message before sending.");
        }
    }

    // Method remains the same, updates the database with the new message
    private void PostPrivateMessage(string message)
    {
        string connectionString = "server=localhost;database=se;uid=root;pwd=1234567;";
        using (MySqlConnection con = new MySqlConnection(connectionString))
        {
            try
            {
                con.Open();
                string sql = @"
                    INSERT INTO Announcements (content, posted_by, visible_to_all, society_id) VALUES 
                    (@content, 
                     (SELECT user_id FROM Users WHERE email = @userEmail), 
                     FALSE, 
                     (SELECT society_id FROM SocietyMemberships WHERE user_id = (SELECT user_id FROM Users WHERE email = @userEmail) LIMIT 1))";

                using (MySqlCommand cmd = new MySqlCommand(sql, con))
                {
                    cmd.Parameters.AddWithValue("@content", message);
                    cmd.Parameters.AddWithValue("@userEmail", userEmail);
                    int rowsAffected = cmd.ExecuteNonQuery();
                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Message sent successfully.");
                        this.Close();
                    }
                    else
                    {
                        MessageBox.Show("Failed to send the message.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error sending message: {ex.Message}");
            }
        }
    }

    // New method to load past messages
    private void LoadPastMessages()
    {
        string connectionString = "server=localhost;database=se;uid=root;pwd=1234567;";
        using (MySqlConnection con = new MySqlConnection(connectionString))
        {
            try
            {
                con.Open();
                string sql = @"
                    SELECT a.content, u.email
                    FROM Announcements a
                    JOIN Users u ON a.posted_by = u.user_id
                    WHERE a.visible_to_all = FALSE
                    AND a.society_id = (SELECT society_id FROM SocietyMemberships WHERE user_id = (SELECT user_id FROM Users WHERE email = @userEmail) LIMIT 1)
                    ORDER BY a.announcement_id DESC"; // Ensure we get the latest messages first

                using (MySqlCommand cmd = new MySqlCommand(sql, con))
                {
                    cmd.Parameters.AddWithValue("@userEmail", userEmail);
                    using (MySqlDataReader reader = cmd.ExecuteReader())
                    {
                        messagesListBox.Items.Clear(); // Clear existing items before loading new ones
                        while (reader.Read())
                        {
                            string message = $"{reader["email"]}: {reader["content"]}";
                            messagesListBox.Items.Add(message);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading messages: {ex.Message}");
            }
        }
    }
}
