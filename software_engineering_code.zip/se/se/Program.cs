﻿using System;
using System.Windows.Forms;

namespace se
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // Create an instance of LoginForm
            LoginForm loginForm = new LoginForm();

            // Show the LoginForm
            Application.Run(loginForm);

            // If the user successfully logs in, create an instance of Form2 and pass the LoginForm instance
            if (loginForm.IsLoggedIn)
            {
                Form2 announcementsForm = new Form2(loginForm.UserEmail, loginForm.UserRole, loginForm.UserId, loginForm);
                announcementsForm.ShowDialog();
            }
        }
    }
}