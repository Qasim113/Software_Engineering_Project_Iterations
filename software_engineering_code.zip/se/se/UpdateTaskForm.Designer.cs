﻿namespace se
{
    partial class UpdateTaskForm
    {
        private System.Windows.Forms.ComboBox comboBoxTasks;
        private System.Windows.Forms.Button btnCompleted30;
        private System.Windows.Forms.Button btnCompleted70;
        private System.Windows.Forms.Button btnCompleted100;

        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        private void InitializeComponent()
        {
            this.SuspendLayout();
            // 
            // UpdateTaskForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Name = "UpdateTaskForm";
            this.Text = "UpdateTaskForm";
            this.Load += new System.EventHandler(this.UpdateTaskForm_Load);

            // Initialize comboBoxTasks
            this.comboBoxTasks = new System.Windows.Forms.ComboBox();
            this.comboBoxTasks.FormattingEnabled = true;
            this.comboBoxTasks.Location = new System.Drawing.Point(100, 50);
            this.comboBoxTasks.Size = new System.Drawing.Size(200, 25);
            this.Controls.Add(this.comboBoxTasks);

            // Initialize btnCompleted30
            this.btnCompleted30 = new System.Windows.Forms.Button();
            this.btnCompleted30.Location = new System.Drawing.Point(100, 100);
            this.btnCompleted30.Size = new System.Drawing.Size(150, 30);
            this.btnCompleted30.Text = "Completed 30%";
            this.btnCompleted30.Click += new System.EventHandler(this.btnCompleted30_Click);
            this.Controls.Add(this.btnCompleted30);

            // Initialize btnCompleted70
            this.btnCompleted70 = new System.Windows.Forms.Button();
            this.btnCompleted70.Location = new System.Drawing.Point(100, 150);
            this.btnCompleted70.Size = new System.Drawing.Size(150, 30);
            this.btnCompleted70.Text = "Completed 70%";
            this.btnCompleted70.Click += new System.EventHandler(this.btnCompleted70_Click);
            this.Controls.Add(this.btnCompleted70);

            // Initialize btnCompleted100
            this.btnCompleted100 = new System.Windows.Forms.Button();
            this.btnCompleted100.Location = new System.Drawing.Point(100, 200);
            this.btnCompleted100.Size = new System.Drawing.Size(150, 30);
            this.btnCompleted100.Text = "Completed 100%";
            this.btnCompleted100.Click += new System.EventHandler(this.btnCompleted100_Click);
            this.Controls.Add(this.btnCompleted100);

            this.ResumeLayout(false);

        }

        #endregion
    }
}
